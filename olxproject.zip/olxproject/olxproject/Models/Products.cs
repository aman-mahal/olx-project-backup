﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace olx.Models
{
    public class Products
    {
        [Required(ErrorMessage = "Product name is required")]
        [MaxLength(45, ErrorMessage = "The maximum length must be upto 45 characters only")]
        public string Name { get; set; }

        
        public string Description { get; set; }


        [RegularExpression(@"^\d+.\d{0,2}$", ErrorMessage = "Has to be decimal with two decimal points")]
        [Range(0, 5, ErrorMessage = "The maximum possible value should be upto 5 digits")]
        public decimal Price { get; set; }

        [Key]
        public int ProductId { get; set; }

        public string ImageUrl { get; set; }

        public bool InStock { get; set; }

        public string ProductLocation { get; set; }

        public int CategoryId { get; set; }

        public Category Category { get; set; }
    }
}
